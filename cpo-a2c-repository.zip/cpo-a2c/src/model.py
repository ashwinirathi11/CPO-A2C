"""CPO-A2C as described in manuscript Sec 4.3 (pure NumPy).

Phase I : Crested Porcupine Optimizer searches a genome of size d+2
          [per-feature inclusion logits | hidden-size selector | log-L2 selector].
Phase II: shared-hidden-layer MLP with an actor head (sigmoid, p(y=1|x)) and a critic head that
          regresses each sample's current BCE loss. Following Sec 4.3.2 the critic is trained
          independently (no gradient into the shared layer), so the classifier is in effect a
          supervised network trained with BCE + Adam plus an auxiliary loss predictor. See
          docs/methodology.md for the consequences for the "A2C" terminology.
"""
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


class ActorCriticMLP:
    def __init__(self, n_in, n_hidden, l2=1e-3, lr=1e-3, seed=42):
        rng = np.random.default_rng(seed)
        self.W1 = rng.normal(0, np.sqrt(2.0 / n_in), (n_in, n_hidden)); self.b1 = np.zeros(n_hidden)
        self.Wa = rng.normal(0, np.sqrt(1.0 / n_hidden), (n_hidden, 1)); self.ba = np.zeros(1)
        self.Wc = rng.normal(0, np.sqrt(1.0 / n_hidden), (n_hidden, 1)); self.bc = np.zeros(1)
        self.l2, self.lr = l2, lr
        self._names = ["W1", "b1", "Wa", "ba", "Wc", "bc"]
        self._m = {k: np.zeros_like(getattr(self, k)) for k in self._names}
        self._v = {k: np.zeros_like(getattr(self, k)) for k in self._names}
        self._t = 0

    def forward(self, X):
        H = np.maximum(0.0, X @ self.W1 + self.b1)
        return H, sigmoid(H @ self.Wa + self.ba).ravel(), (H @ self.Wc + self.bc).ravel()

    def _adam(self, grads, b1=0.9, b2=0.999, eps=1e-8):
        self._t += 1
        for k, g in grads.items():
            self._m[k] = b1 * self._m[k] + (1 - b1) * g
            self._v[k] = b2 * self._v[k] + (1 - b2) * g * g
            mh = self._m[k] / (1 - b1 ** self._t)
            vh = self._v[k] / (1 - b2 ** self._t)
            setattr(self, k, getattr(self, k) - self.lr * mh / (np.sqrt(vh) + eps))

    def step(self, X, y):
        n = len(y)
        H, p, c = self.forward(X)
        dz = ((p - y) / n)[:, None]                              # d BCE / d logit
        gWa = H.T @ dz + self.l2 * self.Wa
        dH = dz @ self.Wa.T
        dH[H <= 0] = 0.0
        gW1 = X.T @ dH + self.l2 * self.W1
        loss_i = -(y * np.log(p + 1e-12) + (1 - y) * np.log(1 - p + 1e-12))
        dc = (2 * (c - loss_i) / n)[:, None]                     # critic: MSE to detached loss
        self._adam({"W1": gW1, "b1": dH.sum(0), "Wa": gWa, "ba": dz.sum(0),
                    "Wc": H.T @ dc, "bc": dc.sum(0)})
        return float(loss_i.mean())

    def fit(self, X, y, epochs=1200, record=False):
        hist = []
        for _ in range(epochs):
            loss = self.step(X, y)
            if record:
                hist.append(loss)
        return hist

    def predict_proba(self, X):
        return self.forward(X)[1]

    def predict_loss(self, X):
        """Critic output: predicted per-sample BCE loss (auxiliary signal, not calibrated confidence)."""
        return self.forward(X)[2]

    def predict(self, X, thr=0.5):
        return (self.predict_proba(X) >= thr).astype(int)


def decode_genome(g, d, hidden_choices, l2_log10_range):
    mask = sigmoid(g[:d]) > 0.5
    if mask.sum() < 3:
        mask[np.argsort(-g[:d])[:3]] = True
    h = hidden_choices[int(np.clip(np.floor((np.tanh(g[d]) + 1) / 2 * len(hidden_choices)), 0,
                                   len(hidden_choices) - 1))]
    lo, hi = l2_log10_range
    l2 = 10 ** (lo + (hi - lo) * (np.tanh(g[d + 1]) + 1) / 2)
    return mask, h, l2


class CrestedPorcupineOptimizer:
    """Four defensive strategies (sight, sound: exploration; odor, physical attack: exploitation),
    greedy acceptance, stagnation-triggered re-initialisation of the worst fraction of agents."""

    def __init__(self, cfg, seed=42):
        self.c, self.rng = cfg, np.random.default_rng(seed)

    def _fit(self, g, Xt, yt, Xv, yv):
        c = self.c
        mask, h, l2 = decode_genome(g, Xt.shape[1], c["hidden_choices"], c["l2_log10_range"])
        net = ActorCriticMLP(int(mask.sum()), h, l2=l2, lr=c["fitness_lr"])
        net.fit(Xt[:, mask], yt, epochs=c["fitness_epochs"])
        return accuracy_score(yv, net.predict(Xv[:, mask]))

    def run(self, Xt, yt, Xv, yv, log=None):
        c, rng = self.c, self.rng
        d = Xt.shape[1]; dim = d + 2; N, T = c["n_agents"], c["n_iterations"]
        pop = rng.normal(0, 1, (N, dim))
        fit = np.array([self._fit(g, Xt, yt, Xv, yv) for g in pop])
        ib = int(fit.argmax()); Xb, fb = pop[ib].copy(), float(fit[ib])
        hist, stall = [fb], 0
        for t in range(1, T + 1):
            alpha = 2 * (1 - t / T); improved = False
            for i in range(N):
                r1, r2 = rng.random(dim), rng.random(dim)
                s = rng.integers(4)
                if s == 0:   new = pop[i] + r1 * (Xb - pop[i]) * np.cos(2 * np.pi * r2)      # sight
                elif s == 1: new = pop[i] + r1 * (Xb - pop[i])                                # sound
                elif s == 2: new = Xb + alpha * r1 * (pop[i] - Xb)                            # odor
                else:        new = Xb + r1 * np.exp(-t / T) * (pop[i] - Xb)                   # physical attack
                fn = self._fit(new, Xt, yt, Xv, yv)
                if fn > fit[i]:
                    pop[i], fit[i] = new, fn
                    if fn > fb:
                        Xb, fb, improved = new.copy(), float(fn), True
            hist.append(fb)
            stall = 0 if improved else stall + 1
            if stall >= c["stagnation_window"]:
                k = max(1, int(c["reinit_fraction"] * N)); worst = np.argsort(fit)[:k]
                pop[worst] = Xb + rng.normal(0, 0.5, (k, dim))
                fit[worst] = [self._fit(g, Xt, yt, Xv, yv) for g in pop[worst]]
                stall = 0
            if log:
                log.info("CPO iter %02d/%d best validation acc %.4f", t, T, fb)
        return Xb, fb, hist


class CPOA2C:
    """Fit on already-standardised training arrays."""

    def __init__(self, cfg, seed=42, use_cpo=True, epochs=None):
        self.cfg, self.seed, self.use_cpo = cfg, seed, use_cpo
        self.epochs = epochs if epochs is not None else cfg["phase2"]["epochs"]

    def fit(self, X, y, log=None):
        c = self.cfg["cpo"]; d = X.shape[1]
        if self.use_cpo:
            Xt, Xv, yt, yv = train_test_split(X, y, test_size=c["validation_size"], stratify=y,
                                              random_state=self.seed)
            g, self.search_fitness_, self.cpo_history_ = CrestedPorcupineOptimizer(c, self.seed).run(
                Xt, yt, Xv, yv, log)
            self.mask_, self.hidden_, self.l2_ = decode_genome(g, d, c["hidden_choices"], c["l2_log10_range"])
        else:
            self.mask_, self.hidden_, self.l2_ = np.ones(d, bool), max(c["hidden_choices"]), 1e-3
        self.net_ = ActorCriticMLP(int(self.mask_.sum()), self.hidden_, l2=self.l2_,
                                   lr=self.cfg["phase2"]["lr"], seed=self.seed)
        self.loss_history_ = self.net_.fit(X[:, self.mask_], y, epochs=self.epochs, record=True)
        return self

    def predict_proba(self, X): return self.net_.predict_proba(X[:, self.mask_])
    def predict(self, X, thr=0.5): return (self.predict_proba(X) >= thr).astype(int)
    def predict_loss(self, X): return self.net_.predict_loss(X[:, self.mask_])
