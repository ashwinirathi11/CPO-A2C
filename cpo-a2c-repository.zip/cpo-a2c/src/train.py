"""Training entry points: CPO-A2C and the six baselines of manuscript Sec 4.4."""
import time

from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

from .model import CPOA2C


def make_baselines(cfg, seed=42):
    return {
        "Random Forest": RandomForestClassifier(cfg["baselines"]["rf_trees"], random_state=seed, n_jobs=-1),
        "SVM": SVC(kernel="rbf", probability=True, random_state=seed),
        "Logistic Regression": LogisticRegression(max_iter=2000),
        "AdaBoost": AdaBoostClassifier(random_state=seed),
        "KNN": KNeighborsClassifier(),
        "Naive Bayes": GaussianNB(),
    }


def train_cpo_a2c(cfg, Xtr, ytr, seed=42, use_cpo=True, epochs=None, log=None):
    t = time.perf_counter()
    m = CPOA2C(cfg, seed=seed, use_cpo=use_cpo, epochs=epochs).fit(Xtr, ytr, log=log)
    return m, time.perf_counter() - t


def timed_predict_proba(model, X, repeats=20):
    """Median wall-clock of predict_proba over repeated calls (after one warm-up call)."""
    import numpy as np
    model.predict_proba(X)
    ts = []
    for _ in range(repeats):
        t = time.perf_counter(); p = model.predict_proba(X); ts.append(time.perf_counter() - t)
    return p, float(np.median(ts)), float(np.std(ts))
