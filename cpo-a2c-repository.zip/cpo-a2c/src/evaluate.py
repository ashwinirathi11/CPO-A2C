"""Metrics, McNemar test, class-wise metrics, error analysis, bootstrap CIs (manuscript Sec 4.5)."""
import numpy as np
from scipy.stats import chi2
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, cohen_kappa_score,
                             confusion_matrix, f1_score, matthews_corrcoef, roc_auc_score)


def basic_metrics(y, pred, proba, sample_weight=None):
    return {"accuracy": accuracy_score(y, pred, sample_weight=sample_weight),
            "f1": f1_score(y, pred, sample_weight=sample_weight),
            "auc": roc_auc_score(y, proba, sample_weight=sample_weight)}


def confusion(y, pred):
    """Orientation: rows = actual [0, 1], columns = predicted [0, 1]  ->  [[TN, FP], [FN, TP]]."""
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp)}


def classwise(y, pred):
    c = confusion(y, pred); tn, fp, fn, tp = c["TN"], c["FP"], c["FN"], c["TP"]
    div = lambda a, b: a / b if b else float("nan")
    pos = {"precision": div(tp, tp + fp), "recall": div(tp, tp + fn), "specificity": div(tn, tn + fp)}
    neg = {"precision": div(tn, tn + fn), "recall": div(tn, tn + fp), "specificity": div(tp, tp + fn)}
    for d in (pos, neg):
        d["f1"] = div(2 * d["precision"] * d["recall"], d["precision"] + d["recall"])
    return {"positive": pos, "negative": neg,
            "overall": {"accuracy": accuracy_score(y, pred), "balanced_accuracy": balanced_accuracy_score(y, pred),
                        "macro_f1": f1_score(y, pred, average="macro"),
                        "weighted_f1": f1_score(y, pred, average="weighted"),
                        "mcc": matthews_corrcoef(y, pred), "kappa": cohen_kappa_score(y, pred)},
            "confusion": c}


def mcnemar(y, pred_a, pred_b):
    """chi2 = (|f01 - f10| - 1)^2 / (f01 + f10); f01 = A correct & B wrong (manuscript Sec 4.5)."""
    a_ok, b_ok = pred_a == y, pred_b == y
    f01, f10 = int((a_ok & ~b_ok).sum()), int((~a_ok & b_ok).sum())
    if f01 + f10 == 0:
        return {"f01": f01, "f10": f10, "chi2": 0.0, "p": 1.0}
    stat = (abs(f01 - f10) - 1) ** 2 / (f01 + f10)
    return {"f01": f01, "f10": f10, "chi2": float(stat), "p": float(chi2.sf(stat, 1))}


def wilson_ci(k, n, z=1.96):
    p = k / n; c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return float(c - h), float(c + h)


def bootstrap_ci(y, pred, proba, n_boot=2000, seed=42):
    rng = np.random.default_rng(seed); n = len(y); acc, auc = [], []
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        if len(np.unique(y[i])) < 2:
            continue
        acc.append(accuracy_score(y[i], pred[i])); auc.append(roc_auc_score(y[i], proba[i]))
    q = lambda a: [float(np.percentile(a, 2.5)), float(np.percentile(a, 97.5))]
    return {"accuracy_ci95": q(acc), "auc_ci95": q(auc)}


def error_analysis(y, proba, thr=0.5, band=0.1):
    pred = (proba >= thr).astype(int); err = pred != y; near = np.abs(proba - thr) < band
    c = confusion(y, pred)
    g = lambda m: float(proba[m].mean()) if m.any() else None
    return {**c, "mean_p_TP": g((pred == 1) & (y == 1)), "mean_p_TN": g((pred == 0) & (y == 0)),
            "mean_p_FN": g((pred == 0) & (y == 1)), "mean_p_FP": g((pred == 1) & (y == 0)),
            "n_near_threshold": int(near.sum()), "errors_near_threshold": int((near & err).sum()),
            "total_errors": int(err.sum()),
            "error_rate_near_threshold": float((near & err).sum() / max(near.sum(), 1)),
            "error_rate_overall": float(err.mean())}
