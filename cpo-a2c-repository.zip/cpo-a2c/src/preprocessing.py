"""Preprocessing and leakage audit (manuscript Sec 4.2).

Two modes:
  * SurveyPreprocessor.fit(train) / transform(any)  -> leakage-free: every statistic
    (missingness filter, indicator selection, imputation modes) comes from training data only.
  * preprocess_full_data(df)  -> reproduces the manuscript's described order of operations
    (statistics computed on the whole dataset BEFORE splitting). It is kept ONLY so the effect
    of that choice can be measured; it should not be used for new work.
"""
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier


class SurveyPreprocessor:
    def __init__(self, id_cols, leakage_cols, target, drop_thr=0.50, flag_thr=0.05):
        self.id_cols, self.leak_cols, self.target = list(id_cols), list(leakage_cols), target
        self.drop_thr, self.flag_thr = drop_thr, flag_thr

    def _base(self, df):
        drop = [c for c in [self.target] + self.id_cols + self.leak_cols if c in df.columns]
        return df.drop(columns=drop).apply(pd.to_numeric, errors="coerce")

    def fit(self, df):
        X = self._base(df)
        miss = X.isna().mean()
        self.keep_ = [c for c in X.columns if miss[c] <= self.drop_thr]
        self.flag_ = [c for c in self.keep_ if miss[c] > self.flag_thr]
        Xk = X[self.keep_]
        self.modes_ = {c: (Xk[c].mode().iloc[0] if Xk[c].notna().any() else 0.0) for c in self.keep_}
        self.n_dropped_missing_ = int((miss > self.drop_thr).sum())
        self.columns_ = self.keep_ + [c + "_missing" for c in self.flag_]
        return self

    def transform(self, df):
        X = self._base(df).reindex(columns=self.keep_)
        out = X.copy()
        for c in self.flag_:
            out[c + "_missing"] = X[c].isna().astype(int)
        for c in self.keep_:
            out[c] = out[c].fillna(self.modes_[c])
        out = out[self.columns_]
        assert not out.isna().any().any(), "NaN left after imputation"
        return out

    def fit_transform(self, df):
        return self.fit(df).transform(df)


def preprocess_full_data(df, id_cols, leakage_cols, target, drop_thr=0.50, flag_thr=0.05):
    """Manuscript-style: filters, flags and imputation computed on ALL rows. Returns X, y."""
    p = SurveyPreprocessor(id_cols, leakage_cols, target, drop_thr, flag_thr).fit(df)
    return p.transform(df), df[target].astype(int).values, p


def leakage_screen(X, y, depth=3, thresh=0.92, seed=42):
    """Depth-3 decision-tree diagnostic (manuscript Sec 5.9): near-deterministic targets are flagged."""
    tree = DecisionTreeClassifier(max_depth=depth, random_state=seed).fit(X, y)
    acc = float(tree.score(X, y))
    return {"depth3_acc": acc, "n_features_used": int((tree.feature_importances_ > 0).sum()),
            "leakage_suspected": acc > thresh}


def audit_target_leakage(df, target, candidates):
    """Cross-tab audit used in manuscript Stage 2: report candidate columns that almost
    deterministically imply the target (every class-0 row has one value / class-1 row another)."""
    out = {}
    for c in candidates:
        if c not in df.columns:
            continue
        ct = pd.crosstab(df[c].fillna(-1), df[target])
        purity = float(ct.max(axis=1).sum() / ct.values.sum())
        out[c] = purity
    return out
