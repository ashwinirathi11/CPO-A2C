"""Loading and validating the Global Findex 2025 India microdata (World Bank catalog 7916).

The dataset is licensed; it must be downloaded by the user from
https://microdata.worldbank.org/catalog/7916 (login + acceptance of the terms of use required).
"""
import zipfile
from pathlib import Path

import pandas as pd

EXPECTED_SHAPE = (3000, 199)      # documented on the catalog page and in manuscript Sec 4.1


def load_findex(path):
    """Read the CSV (or a ZIP containing it). Raises a clear error if the file is absent."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at '{path}'. Download 'Findex_Microdata_2025_updateIndia' "
            "(CSV) from https://microdata.worldbank.org/catalog/7916 and place it there "
            "(see data/README.md)."
        )
    if path.suffix == ".zip":
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.lower().endswith(".csv")]
            if not names:
                raise ValueError(f"No CSV file inside {path}")
            with z.open(names[0]) as f:
                return pd.read_csv(f, low_memory=False)
    if path.suffix == ".dta":
        return pd.read_stata(path)
    return pd.read_csv(path, low_memory=False)


def validate_raw(df, target):
    """Integrity checks required by the reproducibility protocol. Returns a report dict."""
    if target not in df.columns:
        raise KeyError(f"Target column '{target}' not found in data.")
    rep = {"shape": tuple(df.shape), "shape_matches_documentation": tuple(df.shape) == EXPECTED_SHAPE}
    rep["target_missing"] = int(df[target].isna().sum())
    if rep["target_missing"]:
        raise ValueError("Target contains missing values.")
    rep["class_counts"] = {int(k): int(v) for k, v in df[target].value_counts().sort_index().items()}
    rep["positive_rate"] = float(df[target].mean())
    rep["duplicate_rows"] = int(df.duplicated().sum())
    if "wpid_random" in df.columns:
        rep["duplicate_respondent_ids"] = int(df["wpid_random"].duplicated().sum())
    rep["columns_all_missing"] = [c for c in df.columns if df[c].isna().all()]
    if not rep["shape_matches_documentation"]:
        rep["warning"] = f"Shape {df.shape} differs from documented {EXPECTED_SHAPE}"
    return rep
