"""Unit tests (no licensed data needed): python -m pytest -q"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.evaluate import classwise, confusion, mcnemar, wilson_ci                       # noqa: E402
from src.model import ActorCriticMLP, CPOA2C, decode_genome, sigmoid                     # noqa: E402
from src.preprocessing import SurveyPreprocessor                                        # noqa: E402
from src.utils import load_config                                                       # noqa: E402


def toy(n=300, d=12, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(n, d)); y = (X[:, 0] + .5 * X[:, 1] + rng.normal(0, .5, n) > 0).astype(int)
    return X, y


def test_confusion_orientation_rows_actual_cols_predicted():
    y = np.array([0, 0, 0, 1, 1]); p = np.array([0, 0, 1, 1, 0])
    c = confusion(y, p)
    assert (c["TN"], c["FP"], c["FN"], c["TP"]) == (2, 1, 1, 1)


def test_classwise_metrics_match_hand_calculation():
    y = np.array([0] * 8 + [1] * 2); p = np.array([0] * 7 + [1] + [1, 0])
    cw = classwise(y, p)["positive"]
    assert cw["precision"] == pytest.approx(0.5) and cw["recall"] == pytest.approx(0.5)
    assert cw["specificity"] == pytest.approx(7 / 8)


def test_mcnemar_formula():
    y = np.zeros(60, int); a = y.copy(); b = y.copy()
    b[:20] = 1                          # B wrong on 20 rows, A right
    a[20:24] = 1                        # A wrong on 4 rows, B right
    r = mcnemar(y, a, b)
    assert (r["f01"], r["f10"]) == (20, 4)
    assert r["chi2"] == pytest.approx((abs(20 - 4) - 1) ** 2 / 24)
    assert 0 < r["p"] < 0.05


def test_wilson_interval_reference_value():
    lo, hi = wilson_ci(811, 900)
    assert lo == pytest.approx(0.8799, abs=2e-3) and hi == pytest.approx(0.9189, abs=2e-3)


def test_preprocessor_fits_on_train_only():
    rng = np.random.default_rng(1)
    tr = pd.DataFrame({"a": rng.integers(1, 4, 100).astype(float), "b": rng.normal(size=100), "dig": rng.integers(0, 2, 100)})
    tr.loc[:60, "b"] = np.nan                                  # 61% missing -> dropped
    tr.loc[:10, "a"] = np.nan                                  # 11% missing -> flagged
    p = SurveyPreprocessor([], [], "dig").fit(tr)
    assert "b" not in p.columns_ and "a_missing" in p.columns_
    te = tr.copy(); te["a"] = 99.0                             # changing test data must not change fitted modes
    modes_before = dict(p.modes_); p.transform(te)
    assert p.modes_ == modes_before
    assert not p.transform(te).isna().any().any()


def test_genome_decoding_ranges():
    cfg = load_config()["cpo"]; d = 20; g = np.random.default_rng(0).normal(size=d + 2)
    mask, h, l2 = decode_genome(g, d, cfg["hidden_choices"], cfg["l2_log10_range"])
    assert mask.dtype == bool and mask.sum() >= 3 and h in cfg["hidden_choices"] and 1e-5 <= l2 <= 1e-2


def test_actor_trains_and_critic_does_not_move_shared_layer():
    X, y = toy(); net = ActorCriticMLP(X.shape[1], 8, seed=0)
    hist = net.fit(X, y, epochs=200, record=True)
    assert hist[-1] < hist[0]
    # critic isolation: changing critic weights leaves actor probabilities unchanged
    p1 = net.predict_proba(X); net.Wc += 5.0; assert np.allclose(p1, net.predict_proba(X))


def test_cpo_a2c_is_deterministic_for_fixed_seed():
    cfg = load_config(); cfg["cpo"].update(n_agents=4, n_iterations=2, fitness_epochs=20); cfg["phase2"]["epochs"] = 40
    X, y = toy(); a = CPOA2C(cfg, seed=7).fit(X, y); b = CPOA2C(cfg, seed=7).fit(X, y)
    assert np.array_equal(a.mask_, b.mask_) and np.allclose(a.predict_proba(X), b.predict_proba(X))


def test_engineered_feature_count_matches_manuscript():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "experiments"))
    from run_extensions import engineer
    X, y = toy(200, 30); Xe, _, n = engineer(X, y, X)
    assert n == 153 + 8 and Xe.shape[1] == 30 + 161


def test_sigmoid_bounds():
    assert sigmoid(np.array([-1e6, 0, 1e6])).tolist() == pytest.approx([0, .5, 1])
