"""Compare recomputed results with the manuscript's reported values and draw figures.

Reads results/<arm>/*.json (written by run_experiments.py) and config/manuscript_values.yaml.
Writes results/reproduction_report.csv, results/reproduction_report.md and results/figures/<arm>/*.png.
Tolerances come from config/config.yaml and were fixed before any run.
"""
import csv
import json
import sys
from pathlib import Path

import numpy as np
import yaml
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                              # noqa: E402
from sklearn.metrics import roc_curve                                        # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.utils import ROOT, load_config                                      # noqa: E402

cfg = load_config(); T = cfg["tolerances"]
REF = yaml.safe_load(open(ROOT / "config" / "manuscript_values.yaml"))
BASE = ["Random Forest", "SVM", "Logistic Regression", "AdaBoost", "KNN", "Naive Bayes"]
rows = []


def status(kind, rep, rec, nd=4):
    d = abs(rec - rep)
    if kind == "det_acc":
        return "Exact" if d < T["deterministic_acc_exact"] else ("Within tolerance" if d <= T["deterministic_acc_tol"] else "Not reproduced")
    if kind == "det_3dp":
        return "Exact" if round(rec, 3) == round(rep, 3) else ("Within tolerance" if d <= 0.01 else "Not reproduced")
    tol = {"sto_acc": T["stochastic_acc"], "sto_f1": T["stochastic_f1"], "sto_auc": T["stochastic_auc"],
           "sto_count": T["stochastic_count"], "cv": T["cv_mean"]}[kind]
    return "Exact" if d < 5e-4 else ("Within tolerance" if d <= tol else "Not reproduced")


def add(arm, ref, metric, rep, rec, kind, note=""):
    d = rec - rep if (rep is not None and rec is not None) else None
    rows.append({"arm": arm, "manuscript_ref": ref, "metric": metric, "reported": rep,
                 "recomputed": None if rec is None else round(float(rec), 4),
                 "abs_diff": None if d is None else round(abs(d), 4),
                 "rel_diff_pct": None if (d is None or rep in (0, None)) else round(100 * abs(d) / abs(rep), 2),
                 "status": "Not available" if rec is None else status(kind, rep, rec), "note": note})


def load(arm):
    p = ROOT / "results" / arm / "metrics.json"
    return json.load(open(p)) if p.exists() else None


def jload(p):
    return json.load(open(p)) if Path(p).exists() else None


NOTE_STO = ("Stochastic CPO search; original script and several settings unavailable (see docs/methodology.md). "
            "Result reported as computed.")
for arm in ["manuscript", "clean"]:
    m = load(arm)
    if not m:
        continue
    for name, (a, f, u) in REF["table1"].items():
        r = m["table1"][name]; det = name != "CPO-A2C"
        add(arm, "Table 1", f"{name} accuracy", a, r["accuracy"], "det_acc" if det else "sto_acc", "" if det else NOTE_STO)
        add(arm, "Table 1", f"{name} F1", f, r["f1"], "det_3dp" if det else "sto_f1")
        add(arm, "Table 1", f"{name} AUC-ROC", u, r["auc"], "det_3dp" if det else "sto_auc")
    add(arm, "Sec 5.3", "CPO-A2C selected features", REF["selected_features"], m["cpo_a2c_config"]["n_selected"], "sto_count", NOTE_STO)
    add(arm, "Fig. 4a", "Phase I best validation accuracy", REF["phase1_best_val_acc"], m["cpo_a2c_config"]["search_best_val_acc"], "sto_acc")
    for k, v in REF["confusion"].items():
        add(arm, "Sec 5.4 / Fig. 7", f"Confusion count {k}", v, m["error_analysis"][k], "sto_count", "Counts of the CPO-A2C test predictions")
    for n, (f01, f10, c2, p) in REF["mcnemar"].items():
        r = m["mcnemar"][n]
        add(arm, "Table 2", f"McNemar CPO-A2C vs {n}: p-value", p, r["p"], "sto_acc")
        agree = (r["p"] < 0.05) == (p < 0.05)
        rows.append({"arm": arm, "manuscript_ref": "Table 2", "metric": f"McNemar vs {n}: significance decision (p<0.05)",
                     "reported": "significant" if p < .05 else "not significant",
                     "recomputed": "significant" if r["p"] < .05 else "not significant", "abs_diff": None,
                     "rel_diff_pct": None, "status": "Exact" if agree else "Not reproduced",
                     "note": "Decision agreement only"})
    for n, (a, f, u) in REF["ablation"].items():
        r = m["ablation"][n]
        add(arm, "Table 3", f"{n} accuracy", a, r["accuracy"], "sto_acc"); add(arm, "Table 3", f"{n} F1", f, r["f1"], "sto_f1")
        add(arm, "Table 3", f"{n} AUC-ROC", u, r["auc"], "sto_auc")
    for k, v in REF["error_analysis"].items():
        add(arm, "Sec 5.10", k, v, m["error_analysis"][k], "sto_count" if "n_" in k or "errors" in k else "sto_acc")
    sv = m["table1"]["SVM"]["predict_proba_median_s"] / m["table1"]["CPO-A2C"]["predict_proba_median_s"]
    add(arm, "Sec 5.3", "predict_proba time ratio SVM / CPO-A2C (x)", REF["inference_speedup_vs_svm"], sv, "sto_count",
        "Hardware dependent; median of repeated calls after warm-up; compares NumPy MLP with scikit-learn SVC")
    cv = jload(ROOT / "results" / arm / "cv.json")
    if cv:
        for k, ref in [("cpo_a2c_mean", "cpo_a2c_mean"), ("logreg_mean", "logreg_mean")]:
            add(arm, "Sec 5.7", f"5-fold CV {k}", REF["cv"][ref], cv[k], "cv")
        add(arm, "Sec 5.7", "5-fold CV mean selected features", REF["cv"]["mean_features"], cv["mean_features"], "sto_count")
    ts = jload(ROOT / "results" / arm / "target_screening.json")
    if ts:
        for t, (rf, d3) in REF["target_screening"].items():
            add(arm, "Table 5", f"{t} RF accuracy", rf, ts[t]["rf_acc"], "sto_acc", "Feature set for alternative targets not specified in manuscript")
            add(arm, "Table 5", f"{t} depth-3 tree accuracy", d3, ts[t]["depth3_acc"], "sto_acc")
ex = jload(ROOT / "results" / "extensions.json")
if ex:
    for k in ["xgboost_269", "rf_tuned_108", "stacking_test_acc", "stacking_cv_mean"]:
        add("manuscript", "Table 4", k, REF["extensions"][k], ex[k], "sto_acc", "XGBoost/stacking settings not specified; library defaults used")

fields = list(rows[0].keys())
with open(ROOT / "results" / "reproduction_report.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fields); w.writeheader(); w.writerows(rows)

# ---------- markdown summary
from collections import Counter
md = ["# Reproduction report", "", "Reported values come from `config/manuscript_values.yaml`; every recomputed value comes from the "
      "experiments in this repository. Tolerances (fixed beforehand): see `config/config.yaml` and `docs/methodology.md`.", ""]
for arm in ["manuscript", "clean"]:
    sub = [r for r in rows if r["arm"] == arm]
    if not sub:
        continue
    c = Counter(r["status"] for r in sub)
    md += [f"## Arm `{arm}` ({'preprocessing statistics from all rows, as the manuscript describes' if arm == 'manuscript' else 'preprocessing fitted on training rows only'})", "",
           "Status counts: " + ", ".join(f"{k}: {v}" for k, v in c.items()), "",
           "| Ref | Metric | Reported | Recomputed | |Diff| | Status |", "|---|---|---|---|---|---|"]
    md += [f"| {r['manuscript_ref']} | {r['metric']} | {r['reported']} | {r['recomputed']} | {r['abs_diff']} | {r['status']} |" for r in sub]
    md.append("")
ms = jload(ROOT / "results" / "clean" / "multi_seed.json")
if ms:
    md += ["## Seed variability (clean arm)", "", f"CPO-A2C test accuracy over seeds {ms['seeds']}: {[round(a,4) for a in ms['accuracy']]} "
           f"(mean {ms['mean']:.4f}, SD {ms['std']:.4f}).", ""]
open(ROOT / "results" / "reproduction_report.md", "w").write("\n".join(md))

# ---------- figures
for arm in ["manuscript", "clean"]:
    m = load(arm)
    if not m:
        continue
    fd = ROOT / "results" / "figures" / arm; fd.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].plot(m["cpo_history"], marker="o", ms=3); ax[0].set(xlabel="CPO iteration", ylabel="best validation accuracy", title="Phase I convergence")
    h = np.array(m["phase2_loss_history"]); k = 25
    ax[1].plot(h, alpha=.35, label="raw"); ax[1].plot(np.convolve(h, np.ones(k) / k, "valid"), label="25-epoch mean")
    ax[1].set(xlabel="epoch", ylabel="training BCE", title="Phase II convergence"); ax[1].legend()
    fig.tight_layout(); fig.savefig(fd / "convergence.png", dpi=300); plt.close(fig)
    P = np.load(ROOT / "results" / arm / "predictions.npz"); y = P["y_test"]
    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    for key in P.files:
        if key.startswith("proba::"):
            fpr, tpr, _ = roc_curve(y, P[key]); n = key.split("::")[1]
            ax.plot(fpr, tpr, lw=2 if n == "CPO-A2C" else 1, label=n)
    ax.plot([0, 1], [0, 1], "k:", lw=.8); ax.set(xlabel="FPR", ylabel="TPR", title="ROC (test, N=900)"); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(fd / "roc.png", dpi=300); plt.close(fig)
    ea = m["error_analysis"]; cmx = np.array([[ea["TN"], ea["FP"]], [ea["FN"], ea["TP"]]])
    fig, ax = plt.subplots(figsize=(3.8, 3.4)); ax.imshow(cmx, cmap="Blues")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cmx[i, j], ha="center", va="center", color="white" if cmx[i, j] > cmx.max() / 2 else "black")
    ax.set(xticks=[0, 1], yticks=[0, 1], xticklabels=["pred 0", "pred 1"], yticklabels=["actual 0", "actual 1"], title="CPO-A2C confusion matrix")
    fig.tight_layout(); fig.savefig(fd / "confusion_matrix.png", dpi=300); plt.close(fig)
    names = list(m["table1"]); acc = [m["table1"][n]["accuracy"] for n in names]
    fig, ax = plt.subplots(figsize=(7, 3.4)); ax.bar(names, acc, color=["tab:red" if n == "CPO-A2C" else "tab:gray" for n in names])
    ax.set(ylim=(min(acc) - .02, max(acc) + .01), ylabel="test accuracy", title="Model comparison"); plt.xticks(rotation=30, ha="right")
    fig.tight_layout(); fig.savefig(fd / "model_comparison.png", dpi=300); plt.close(fig)
print("report written:", len(rows), "rows")
