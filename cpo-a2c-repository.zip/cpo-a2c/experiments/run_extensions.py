"""Extension experiments of manuscript Sec 5.8 / Table 4 (manuscript-style preprocessing arm).

 * interaction + polynomial features: all C(18,2)=153 pairwise products among the 18 features most
   correlated with the target (correlation computed on TRAINING rows only), plus squares of the 8 most
   correlated of those -> 108 + 161 = 269 features
 * XGBoost on the 269 features; tuned Random Forest (500 trees, depth 8) on the 108 base features
 * stacking (RF, SVM, LR, XGBoost -> logistic-regression meta-learner, 5-fold out-of-fold predictions)
   evaluated on the test split and by 5-fold outer CV.
XGBoost/stacking hyper-parameters are not given in the manuscript; defaults are used (documented).
"""
import itertools
import sys
from pathlib import Path

import numpy as np
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.data_loader import load_findex                                    # noqa: E402
from src.preprocessing import preprocess_full_data                          # noqa: E402
from src.utils import ROOT, get_logger, load_config, save_json              # noqa: E402

log = get_logger()


def engineer(Xtr, ytr, Xte, top=18, sq=8):
    corr = np.nan_to_num([abs(np.corrcoef(Xtr[:, j], ytr)[0, 1]) for j in range(Xtr.shape[1])])
    order = np.argsort(-corr)[:top]
    pairs = list(itertools.combinations(order, 2))
    sq_idx = order[:sq]
    f = lambda X: np.hstack([X] + [(X[:, i] * X[:, j])[:, None] for i, j in pairs] + [(X[:, i] ** 2)[:, None] for i in sq_idx])
    return f(Xtr), f(Xte), len(pairs) + len(sq_idx)


def stack(seed):
    from xgboost import XGBClassifier
    xgb = XGBClassifier(random_state=seed, eval_metric="logloss", n_jobs=-1)
    return StackingClassifier(
        estimators=[("rf", RandomForestClassifier(500, max_depth=8, random_state=seed, n_jobs=-1)),
                    ("svm", SVC(probability=True, random_state=seed)),
                    ("lr", LogisticRegression(max_iter=2000)), ("xgb", xgb)],
        final_estimator=LogisticRegression(max_iter=2000),
        cv=StratifiedKFold(5, shuffle=True, random_state=seed), n_jobs=1)


if __name__ == "__main__":
    from xgboost import XGBClassifier
    cfg = load_config(); d, seed = cfg["data"], cfg["seed"]
    df = load_findex(ROOT / d["path"])
    X, y, _ = preprocess_full_data(df, d["id_columns"], d["leakage_columns"], d["target"])
    tr, te = train_test_split(np.arange(len(y)), test_size=.3, stratify=y, random_state=cfg["split"]["random_state"])
    sc = StandardScaler().fit(X.values[tr]); Xtr, Xte = sc.transform(X.values[tr]), sc.transform(X.values[te])
    ytr, yte = y[tr], y[te]
    Xtr_e, Xte_e, n_eng = engineer(Xtr, ytr, Xte, cfg["extensions"]["top_corr_features"], cfg["extensions"]["squared_terms"])
    log.info("engineered features: %d added, matrix %s", n_eng, Xtr_e.shape)
    out = {"n_engineered_terms": n_eng, "n_features_total": int(Xtr_e.shape[1])}
    xgb = XGBClassifier(random_state=seed, eval_metric="logloss", n_jobs=-1).fit(Xtr_e, ytr)
    out["xgboost_269"] = float(accuracy_score(yte, xgb.predict(Xte_e)))
    rf = RandomForestClassifier(500, max_depth=8, random_state=seed, n_jobs=-1).fit(Xtr, ytr)
    out["rf_tuned_108"] = float(accuracy_score(yte, rf.predict(Xte)))
    st = stack(seed).fit(Xtr_e, ytr); out["stacking_test_acc"] = float(accuracy_score(yte, st.predict(Xte_e)))
    # outer 5-fold CV on the full (train+test) data; engineering recomputed inside each fold
    accs = []
    for a, b in StratifiedKFold(5, shuffle=True, random_state=seed).split(X.values, y):
        s2 = StandardScaler().fit(X.values[a]); A, B = s2.transform(X.values[a]), s2.transform(X.values[b])
        Ae, Be, _ = engineer(A, y[a], B)
        accs.append(float(accuracy_score(y[b], stack(seed).fit(Ae, y[a]).predict(Be))))
        log.info("stack CV fold acc %.4f", accs[-1])
    out["stacking_cv_folds"] = accs; out["stacking_cv_mean"] = float(np.mean(accs)); out["stacking_cv_std"] = float(np.std(accs))
    save_json(out, ROOT / "results" / "extensions.json"); log.info(out)
