"""Run the CPO-A2C experiments for one preprocessing arm.

  --arm manuscript : statistics (missingness filter, flags, imputation) computed on the full data
                     before splitting, exactly as the manuscript describes. Kept to measure the
                     effect of that choice.
  --arm clean      : all preprocessing statistics fitted on training data only (no leakage).

Outputs are written to results/<arm>/ (metrics.json, predictions.npz, ...). Nothing here reads
the manuscript's reported values; comparison happens in experiments/make_report.py.
"""
import argparse
import sys
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.data_loader import load_findex, validate_raw                      # noqa: E402
from src.evaluate import (basic_metrics, bootstrap_ci, classwise, confusion, error_analysis,   # noqa: E402
                          mcnemar, wilson_ci)
from src.model import ActorCriticMLP                                        # noqa: E402
from src.preprocessing import SurveyPreprocessor, leakage_screen, preprocess_full_data   # noqa: E402
from src.train import make_baselines, timed_predict_proba, train_cpo_a2c      # noqa: E402
from src.utils import ROOT, get_logger, load_config, save_json, set_seed      # noqa: E402

log = get_logger()


def build_arrays(cfg, df, arm, tr_idx, te_idx):
    d = cfg["data"]
    mk = lambda: SurveyPreprocessor(d["id_columns"], d["leakage_columns"], d["target"],
                                    d["missing_drop_threshold"], d["missing_flag_threshold"])
    y = df[d["target"]].astype(int).values
    if arm == "manuscript":
        X, _, p = preprocess_full_data(df, d["id_columns"], d["leakage_columns"], d["target"],
                                       d["missing_drop_threshold"], d["missing_flag_threshold"])
        Xtr, Xte = X.iloc[tr_idx], X.iloc[te_idx]
    else:
        p = mk().fit(df.iloc[tr_idx])
        Xtr, Xte = p.transform(df.iloc[tr_idx]), p.transform(df.iloc[te_idx])
    sc = StandardScaler().fit(Xtr.values.astype(float))
    return (sc.transform(Xtr.values.astype(float)), sc.transform(Xte.values.astype(float)),
            y[tr_idx], y[te_idx], list(Xtr.columns), p)


def main_experiment(cfg, df, arm, seed, out):
    d, s = cfg["data"], cfg["split"]
    y_all = df[d["target"]].astype(int).values
    idx = np.arange(len(df))
    tr, te = train_test_split(idx, test_size=s["test_size"], stratify=y_all, random_state=s["random_state"])
    Xtr, Xte, ytr, yte, names, prep = build_arrays(cfg, df, arm, tr, te)
    log.info("[%s] train %s test %s features %d", arm, Xtr.shape, Xte.shape, Xtr.shape[1])
    res = {"arm": arm, "seed": seed, "n_features_base": Xtr.shape[1], "n_train": len(ytr), "n_test": len(yte)}
    preds, probas, models = {}, {}, {}

    # CPO-A2C
    model, ttrain = train_cpo_a2c(cfg, Xtr, ytr, seed=seed, log=log)
    p_te, tmed, tsd = timed_predict_proba(model, Xte)
    preds["CPO-A2C"], probas["CPO-A2C"] = (p_te >= 0.5).astype(int), p_te
    res["table1"] = {"CPO-A2C": {**basic_metrics(yte, preds["CPO-A2C"], p_te), "train_s": ttrain,
                                 "predict_proba_median_s": tmed, "predict_proba_sd_s": tsd}}
    res["cpo_a2c_config"] = {"n_selected": int(model.mask_.sum()), "hidden": int(model.hidden_),
                             "l2": float(model.l2_), "search_best_val_acc": float(model.search_fitness_)}
    # baselines
    for name, clf in make_baselines(cfg, seed).items():
        import time
        t = time.perf_counter(); clf.fit(Xtr, ytr); tt = time.perf_counter() - t
        pr, tm, ts = timed_predict_proba(clf, Xte, repeats=5)
        preds[name], probas[name] = (pr[:, 1] >= 0.5).astype(int), pr[:, 1]
        res["table1"][name] = {**basic_metrics(yte, preds[name], pr[:, 1]), "train_s": tt,
                               "predict_proba_median_s": tm, "predict_proba_sd_s": ts}
        models[name] = clf
    # McNemar (Table 2)
    res["mcnemar"] = {n: mcnemar(yte, preds["CPO-A2C"], preds[n]) for n in make_baselines(cfg, seed)}
    # class-wise, CI, errors
    res["classwise"] = {n: classwise(yte, preds[n]) for n in ["CPO-A2C", "Random Forest", "SVM"]}
    res["ci"] = {**bootstrap_ci(yte, preds["CPO-A2C"], probas["CPO-A2C"], seed=seed),
                 "accuracy_wilson95": wilson_ci(int((preds["CPO-A2C"] == yte).sum()), len(yte))}
    res["error_analysis"] = error_analysis(yte, probas["CPO-A2C"])
    # survey-weighted sensitivity (weights NOT used in training)
    if "wgt" in df.columns:
        w = df["wgt"].values[te]
        res["weighted_test"] = {n: basic_metrics(yte, preds[n], probas[n], sample_weight=w)
                                for n in ["CPO-A2C", "Random Forest", "SVM", "Logistic Regression"]}
    # critic head diagnostics: correlation between predicted and actual per-sample loss
    pl = model.predict_loss(Xte); pc = np.clip(probas["CPO-A2C"], 1e-12, 1 - 1e-12)
    al = -(yte * np.log(pc) + (1 - yte) * np.log(1 - pc))
    res["critic_loss_corr"] = float(np.corrcoef(pl, al)[0, 1])

    # Ablation (Table 3)
    abl = {}
    m_all, _ = train_cpo_a2c(cfg, Xtr, ytr, seed=seed, use_cpo=False)
    pa = m_all.predict_proba(Xte); abl["All features + A2C (no CPO)"] = basic_metrics(yte, (pa >= .5).astype(int), pa)
    short = ActorCriticMLP(int(model.mask_.sum()), model.hidden_, l2=model.l2_, lr=cfg["phase2"]["lr"], seed=seed)
    short.fit(Xtr[:, model.mask_], ytr, epochs=cfg["ablation"]["short_epochs"])
    ps = short.predict_proba(Xte[:, model.mask_]); abl["CPO selection + short training"] = basic_metrics(yte, (ps >= .5).astype(int), ps)
    abl["Full CPO-A2C"] = {k: res["table1"]["CPO-A2C"][k] for k in ("accuracy", "f1", "auc")}
    res["ablation"] = abl
    pr_ = {"all": (pa >= .5).astype(int), "short": (ps >= .5).astype(int), "full": preds["CPO-A2C"]}
    res["ablation_mcnemar"] = {"full_vs_all": mcnemar(yte, pr_["full"], pr_["all"]),
                               "full_vs_short": mcnemar(yte, pr_["full"], pr_["short"]),
                               "short_vs_all": mcnemar(yte, pr_["short"], pr_["all"])}
    res["selected_features"] = [n for n, k in zip(names, model.mask_) if k]
    res["cpo_history"] = model.cpo_history_
    res["phase2_loss_history"] = model.loss_history_
    save_json(res, out / "metrics.json")
    np.savez_compressed(out / "predictions.npz", y_test=yte, **{f"proba::{k}": v for k, v in probas.items()})
    log.info("[%s] main done: CPO-A2C acc %.4f", arm, res["table1"]["CPO-A2C"]["accuracy"])
    return res


def cv_experiment(cfg, df, arm, seed, out):
    d = cfg["data"]; y = df[d["target"]].astype(int).values
    skf = StratifiedKFold(cfg["split"]["cv_folds"], shuffle=True, random_state=cfg["split"]["random_state"])
    rows = []
    for k, (a, b) in enumerate(skf.split(np.zeros(len(y)), y), 1):
        Xa, Xb, ya, yb, _, _ = build_arrays(cfg, df, arm, a, b)
        m, _ = train_cpo_a2c(cfg, Xa, ya, seed=seed)
        lr = LogisticRegression(max_iter=2000).fit(Xa, ya)
        rows.append({"fold": k, "cpo_a2c_acc": accuracy_score(yb, m.predict(Xb)),
                     "logreg_acc": accuracy_score(yb, lr.predict(Xb)), "n_features": int(m.mask_.sum())})
        log.info("[%s] CV fold %d: CPO-A2C %.4f LogReg %.4f features %d", arm, k, rows[-1]["cpo_a2c_acc"],
                 rows[-1]["logreg_acc"], rows[-1]["n_features"])
    a2c = np.array([r["cpo_a2c_acc"] for r in rows]); lr_ = np.array([r["logreg_acc"] for r in rows])
    res = {"folds": rows, "cpo_a2c_mean": float(a2c.mean()), "cpo_a2c_std": float(a2c.std()),
           "logreg_mean": float(lr_.mean()), "logreg_std": float(lr_.std()),
           "mean_features": float(np.mean([r["n_features"] for r in rows]))}
    save_json(res, out / "cv.json")
    return res


def screen_targets(cfg, df, out):
    """Alternative-target leakage screen (Sec 5.9). The manuscript does not specify the feature
    set used for these targets; here: all numeric columns except the candidate itself and ID columns."""
    from sklearn.ensemble import RandomForestClassifier
    d = cfg["data"]; rows = {}
    for tgt in ["saved", "borrowed", "anydigpayment", "merchantpay_dig", "internet_use"]:
        X = df.drop(columns=[c for c in [tgt] + d["id_columns"] if c in df.columns]).apply(
            lambda s: __import__("pandas").to_numeric(s, errors="coerce")).fillna(0)
        y = df[tgt].fillna(0).astype(int).values
        Xt, Xe, yt, ye = train_test_split(X.values, y, test_size=.3, stratify=y, random_state=42)
        rf = RandomForestClassifier(300, random_state=42, n_jobs=-1).fit(Xt, yt)
        rows[tgt] = {"rf_acc": float(rf.score(Xe, ye)), **leakage_screen(X, y)}
    save_json(rows, out / "target_screening.json")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", choices=["manuscript", "clean"], required=True)
    ap.add_argument("--config", default=None)
    ap.add_argument("--data", default=None, help="override data path")
    ap.add_argument("--skip-cv", action="store_true")
    ap.add_argument("--multi-seed", action="store_true")
    ap.add_argument("--screen", action="store_true")
    ap.add_argument("--quick", action="store_true", help="tiny CPO/epochs for a smoke test")
    a = ap.parse_args()
    cfg = load_config(a.config)
    if a.quick:
        cfg["cpo"].update(n_agents=6, n_iterations=4); cfg["phase2"]["epochs"] = 200
    set_seed(cfg["seed"])
    path = Path(a.data or cfg["data"]["path"]); path = path if path.is_absolute() else ROOT / path
    df = load_findex(path)
    rep = validate_raw(df, cfg["data"]["target"])
    out = ROOT / "results" / (a.arm + ("_quick" if a.quick else "")); out.mkdir(parents=True, exist_ok=True)
    save_json(rep, out / "data_validation.json"); log.info("data validation: %s", rep)
    main_experiment(cfg, df, a.arm, cfg["seed"], out)
    if not a.skip_cv:
        cv_experiment(cfg, df, a.arm, cfg["seed"], out)
    if a.multi_seed:
        accs = []
        for sd in cfg["multi_seed"]:
            Xtr_idx = None
            m = main_experiment(cfg, df, a.arm, sd, out / f"seed_{sd}"); accs.append(m["table1"]["CPO-A2C"]["accuracy"])
        save_json({"seeds": cfg["multi_seed"], "accuracy": accs, "mean": float(np.mean(accs)),
                   "std": float(np.std(accs))}, out / "multi_seed.json")
    if a.screen:
        screen_targets(cfg, df, out)
