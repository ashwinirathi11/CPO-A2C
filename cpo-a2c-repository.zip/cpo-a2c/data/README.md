# Data

## Dataset (not redistributed)

**The Global Findex Database 2025: Connectivity and Financial Inclusion in the Digital Economy - India, 2024**

| Field | Value |
|---|---|
| Source | World Bank Microdata Library, catalog 7916 |
| Landing page | https://microdata.worldbank.org/catalog/7916 |
| Reference ID | `IND_2024_FINDEX_v02_M` |
| Dataset DOI | https://doi.org/10.48529/c9vy-pq51 |
| Data file | `Findex_Microdata_2025_updateIndia` (CSV) |
| Size | 3,000 respondents x 199 variables (checked by `src/data_loader.validate_raw`) |
| Fieldwork | face-to-face, nationally representative, May-December 2024 (as stated in the manuscript) |
| Report | Klapper, Singer, Starita, Norris (2025), World Bank, DOI 10.1596/978-1-4648-2204-9 |

### Access
The microdata are licensed. Log in (free registration) at the catalog page, accept the terms of use and
download the CSV package. **Do not commit or redistribute the file** (`data/raw/` is git-ignored).
Documentation on the same page: questionnaires, microdata codebook, indicator mapping, and the
variable-naming R script.

### Expected location
```
data/raw/Findex_Microdata_2025_updateIndia.csv      # path set in config/config.yaml
```
A `.zip` containing the CSV or a `.dta` file is also accepted by `src/data_loader.py`.

### Target and columns used
* Target: `dig_account` (1 = digitally enabled account; 1,968 negative / 1,032 positive).
* Removed as identifiers (7): `year, economy, economycode, regionwb, pop_adult, wpid_random, wgt`
  (`wgt` is the survey weight; models are trained **unweighted**, weighted test metrics are reported separately).
* Removed as target leakage (6): `account, account_mob, account_fin, fin3, fin9a, fin9b`.
* Remaining 185 candidates -> columns with >50% missing are dropped, columns with 5-50% missing get a
  missing-indicator flag, then mode imputation. The manuscript reports 108 final predictors; the
  full-data preprocessing in this repository reproduces that count.

### Integrity checks run on load
shape vs. documentation, missing target, class balance, duplicated rows, duplicated respondent IDs,
all-missing columns (18 are all-missing in this extract) -> written to `results/<arm>/data_validation.json`.
