# A Novel Crested Porcupine Optimizer-Advantage Actor-Critic (CPO-A2C) Hybrid Framework for Efficient and Generalizable Probabilistic Decision Intelligence

Code and reproduction pipeline for the manuscript by Ashwini V. Rathi and Rajkumar Jha
(G. H. Raisoni University, Amravati, India). *The manuscript is under review; no DOI exists yet.*

## Overview
The study classifies digitally-enabled account ownership (`dig_account`) from Global Findex 2025 India
microdata (N = 3,000, 108 predictors after a leakage audit). **CPO-A2C** is a two-phase model: the Crested Porcupine
Optimizer (CPO) searches feature subsets and network hyper-parameters (Phase I); the selected network is then trained
with Adam, with an auxiliary critic head that predicts each sample's loss (Phase II). The manuscript evaluates it
against six baselines (McNemar tests, ablation, 5-fold CV), screens alternative targets for composite-indicator
leakage, and tests feature-engineering / ensemble extensions.

## Repository structure
```
config/        config.yaml (all settings; ASSUMPTION flags), manuscript_values.yaml (reported numbers, reference only)
data/          README.md (official source and access); raw/ is git-ignored
src/           data_loader, preprocessing, model (CPO + actor-critic MLP), train, evaluate, utils
experiments/   run_experiments.py, run_extensions.py, make_report.py
tests/         test_pipeline.py (10 unit tests, no licensed data needed)
results/       reproduction_report.{csv,md}, per-arm metrics, figures/, logs/
docs/          methodology.md (assumptions, tolerances, A2C terminology note)
scripts/       reproduce_results.sh
notebooks/     experimental_analysis.ipynb
```

## Requirements
Python 3.12 (tested), NumPy, pandas, SciPy, scikit-learn, matplotlib, PyYAML, XGBoost (extensions only). CPU only.
Versions used for the reported run: scikit-learn 1.9.1, NumPy 2.5.4, Python 3.12.3. Runtime (observed): about 1 minute for the main experiment of one arm, and about 25 minutes for the full pipeline
with three jobs sharing a CPU (the CPO search dominates).
Results of AdaBoost and k-NN can change with scikit-learn versions.

## Data
Official dataset: Global Findex Database 2025, India (World Bank Microdata Library, catalog 7916, reference
`IND_2024_FINDEX_v02_M`, DOI 10.48529/c9vy-pq51). It is licensed, requires a free login and acceptance of the terms
of use, and is **not** included here. Place the CSV at `data/raw/Findex_Microdata_2025_updateIndia.csv`.
Details: `data/README.md`.

## Installation and execution
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # or: conda env create -f environment.yml
python -m pytest -q tests                  # unit tests
python experiments/run_experiments.py --arm manuscript --screen    # manuscript's preprocessing order + Table 5 screen
python experiments/run_experiments.py --arm clean --multi-seed     # leakage-free order + 5 seeds
python experiments/run_extensions.py                                # Table 4 extensions
python experiments/make_report.py                                   # reproduction report + figures
# or everything: bash scripts/reproduce_results.sh
```
Use `--quick` for a smoke test (not for reporting).

## Reproducing the manuscript: current status
Full details are in `results/reproduction_report.md` (132 compared values across two arms). Summary of the
`manuscript` arm (73 comparisons): 18 exact, 28 within tolerance, 27 not reproduced.

* **Reproduced exactly:** dataset and split (2,100 / 900), 108 predictors, class balance, and the test accuracy of
  Random Forest (0.9056), SVM (0.9044), Logistic Regression (0.8989) and Naive Bayes (0.8000); 5-fold CV accuracy of
  logistic regression (0.9067 +/- 0.0067); tuned random forest (0.9067); the 161 engineered terms; the leakage
  diagnosis of all five alternative targets.
* **Within tolerance:** k-NN, XGBoost on 269 features (0.9011 vs 0.9056), stacking CV (0.9097 vs 0.9113).
* **Not reproduced:** the headline CPO-A2C result. With seed 42 and the documented settings the code gives 88.56%
  accuracy, F1 0.829, AUC 0.941, 53 selected features and confusion matrix 548/42/61/249, versus 90.11%, 0.840, 0.937,
  65 and 578/12/77/233 in the manuscript. Over seeds 42-46 test accuracy is 0.8947 +/- 0.0058 (range 0.8856-0.9033),
  so the reported 90.11% lies within the range of seed variability but is not obtained at seed 42.
  AdaBoost (0.8944 vs 0.9000) also differs, possibly because of scikit-learn version defaults.
* **Qualitative claims that did not reproduce with this code:** (i) CPO-A2C is statistically indistinguishable from
  Random Forest and SVM (here McNemar p = 0.018 and 0.017, significant); (ii) the ablation is monotonic
  (here all features + A2C 0.8933 > full CPO-A2C 0.8856 > CPO + short training 0.8767, with no significant pairwise
  difference); (iii) the critic head output is only weakly related to the realised per-sample loss (r = 0.12).
* **Preprocessing order:** fitting the missingness filter/imputation on all rows (as described) or on training rows
  only gives identical matrices on this dataset, hence identical results.

The original script that produced the manuscript's CPO-A2C numbers was not available, and several settings are not
stated in the manuscript (listed in `config/config.yaml` as ASSUMPTION). The code reports what it computes; it was
not tuned to match the paper.

## Known limitations
* The actor-critic here is not a policy-gradient A2C: the critic does not influence the actor update (see
  `docs/methodology.md`).
* Single country, single survey wave; headline metrics are unweighted sample metrics.
* CPO fitness uses one inner validation split, which can make the search optimistic.
* Timing comparisons (NumPy MLP vs scikit-learn SVC) depend on hardware.

## Citation
See `CITATION.cff`. Add the journal, year and DOI after publication.

## Licence and responsible data use
Code: MIT (to be confirmed by the authors, see `LICENSE`). The Findex microdata remain under World Bank terms; do not
redistribute them, and do not attempt to re-identify respondents.
