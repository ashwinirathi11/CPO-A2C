# Publishing on GitHub

```bash
cd cpo-a2c
git init && git add . && git status          # confirm data/raw/ and *.zip are NOT listed
git commit -m "CPO-A2C: code, tests and reproduction pipeline"
git branch -M main
# create an EMPTY public repository on github.com (no README/licence), then:
git remote add origin https://github.com/<user>/cpo-a2c.git
git push -u origin main
```
Check: open the repository URL in a private/incognito window (no login) and confirm README, code and
`results/reproduction_report.md` are visible. Then fill `repository-code` in `CITATION.cff`. Confirm the licence
with all authors (and the university, if required) before making the repository public.

## Code availability statement
Provisional (repository not yet public):
"Source code and experimental scripts will be made publicly available upon acceptance. The Global Findex 2025 India
microdata are available from the World Bank Microdata Library (https://microdata.worldbank.org/catalog/7916) subject to
its terms of use."

After publication and verification (replace the URL):
"Source code and experimental scripts for the analyses in this study are available at [VERIFIED PUBLIC GITHUB URL].
Dataset sources, setup instructions, evaluation procedures and a manuscript-versus-recomputed results report are
documented in the repository. Where recomputed values differ from those in the manuscript, the differences are
reported in the repository."
