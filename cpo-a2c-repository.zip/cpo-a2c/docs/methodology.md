# Methodology, assumptions and tolerances

## Pipeline (manuscript Sec 4)
1. **Load + validate** the India microdata (3,000 x 199).
2. **Preprocess** (Sec 4.2): drop 7 identifiers and 6 leakage columns; drop columns >50% missing; add
   missing-indicator flags for 5-50% missing; mode imputation; standardise with training statistics.
3. **Split**: stratified 70/30, `random_state=42` (2,100 train / 900 test).
4. **Phase I - CPO** (Sec 4.3.1): genome of size d+2 = [d feature-inclusion logits, hidden-size selector,
   log-L2 selector]. Fitness = validation accuracy of a 100-epoch network on the selected features.
   Four update rules (sight, sound, odor, physical attack), greedy acceptance, 20% worst-agent
   re-initialisation after stagnation.
5. **Phase II** (Sec 4.3.2): shared hidden layer, actor head (sigmoid) trained with binary cross-entropy +
   L2 + Adam; critic head regressing the sample's current BCE loss, trained independently.
6. **Baselines**: SVM (RBF), logistic regression, random forest (300 trees), AdaBoost, k-NN, Gaussian NB.
7. **Evaluation**: accuracy, F1, AUC; McNemar (continuity-corrected); class-wise metrics; ablation;
   5-fold CV with the whole CPO search repeated inside each training fold.

## Two preprocessing arms
| Arm | Statistics for missingness filter / flags / imputation | Purpose |
|---|---|---|
| `manuscript` | computed on all 3,000 rows before splitting (as the manuscript describes) | faithful to the paper; measures the effect of that order |
| `clean` | computed on training rows only (and inside each CV fold) | leakage-free protocol; recommended |

These steps do not use the label, so any effect is expected to be small, but they are not leakage-free.

## Settings the manuscript does not state (ASSUMPTIONS, all in `config/config.yaml`)
CPO population (20), stagnation window (5), validation split for CPO fitness (25%), fitness learning rate
(0.01), L2 range (1e-5 to 1e-2), Phase II learning rate (0.001), ReLU activation, He-style initialisation,
full-batch training, baseline hyper-parameters other than RF trees (library defaults), XGBoost and stacking
settings (library defaults), the feature set used for alternative-target screening.
Software versions matter: AdaBoost and k-NN defaults changed across scikit-learn releases; versions used are
in `results/README.md` / the run logs.

## Tolerances (fixed before the final runs)
| Quantity | Exact | Within tolerance |
|---|---|---|
| Deterministic baseline accuracy (N=900) | abs diff < 0.0005 (4-dp equality) | <= 0.0034 (<= 3 test cases) |
| Deterministic baseline F1 / AUC (3 dp) | equal after rounding to 3 dp | abs diff <= 0.01 |
| CPO-A2C accuracy / AUC | abs diff < 0.0005 | <= 0.010 |
| CPO-A2C F1 | abs diff < 0.0005 | <= 0.020 |
| Selected-feature count / confusion counts | exact | within 10 |
| CV mean accuracy | exact | <= 0.010 |

Rationale: baselines are deterministic given the split and library versions, so they should match to the
last reported digit; CPO-A2C depends on a stochastic search, an unstated configuration and floating-point
order, so a 1-percentage-point band (9 of 900 test cases) is allowed. Status labels: **Exact**,
**Within tolerance**, **Partial** (some, not all, quantities of one experiment agree), **Not reproduced**.

## On the "A2C" terminology
The critic head is trained by mean-squared-error regression and never changes the actor's gradient
(manuscript Sec 4.3.2). The model is therefore a supervised MLP trained with cross-entropy and Adam plus an
auxiliary loss-prediction head. It has no sampled action, reward, advantage or policy-gradient update. The code
implements the manuscript as written and does not add an advantage-based update. `results/*/metrics.json`
reports the correlation between the critic's output and the realised per-sample loss (`critic_loss_corr`)
so the usefulness of the auxiliary head can be judged.

## Sources of nondeterminism
Seeds are fixed (default 42). The NumPy implementation is deterministic on a given machine; BLAS thread
order can change the last floating-point digits across machines. Random forest uses `random_state`.
Timing results depend on hardware and load.

## Survey weights
`wgt` is excluded from the features and from training. `weighted_test` in `metrics.json` reports
weighted accuracy/F1/AUC on the test rows as a sensitivity check; the headline numbers are unweighted
and describe the sample, not the Indian adult population.

## Observed effect of the preprocessing order (this dataset)
On the main split and on all five CV folds, fitting the missingness filter, flags and imputation on training rows
only produced exactly the same feature matrix (same columns, 0 differing cells) as fitting them on all rows.
The two arms therefore give identical results here. The leakage-free order is still the correct protocol and
is the default for any new data.
