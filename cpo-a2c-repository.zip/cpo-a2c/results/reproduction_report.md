# Reproduction report

Reported values come from `config/manuscript_values.yaml`; every recomputed value comes from the experiments in this repository. Tolerances (fixed beforehand): see `config/config.yaml` and `docs/methodology.md`.

## Arm `manuscript` (preprocessing statistics from all rows, as the manuscript describes)

Status counts: Exact: 18, Within tolerance: 28, Not reproduced: 27

| Ref | Metric | Reported | Recomputed | |Diff| | Status |
|---|---|---|---|---|---|
| Table 1 | Random Forest accuracy | 0.9056 | 0.9056 | 0.0 | Exact |
| Table 1 | Random Forest F1 | 0.851 | 0.8506 | 0.0004 | Exact |
| Table 1 | Random Forest AUC-ROC | 0.955 | 0.955 | 0.0 | Exact |
| Table 1 | SVM accuracy | 0.9044 | 0.9044 | 0.0 | Exact |
| Table 1 | SVM F1 | 0.847 | 0.8522 | 0.0052 | Within tolerance |
| Table 1 | SVM AUC-ROC | 0.95 | 0.95 | 0.0 | Exact |
| Table 1 | CPO-A2C accuracy | 0.9011 | 0.8856 | 0.0155 | Not reproduced |
| Table 1 | CPO-A2C F1 | 0.84 | 0.8286 | 0.0114 | Within tolerance |
| Table 1 | CPO-A2C AUC-ROC | 0.937 | 0.9407 | 0.0037 | Within tolerance |
| Table 1 | AdaBoost accuracy | 0.9 | 0.8944 | 0.0056 | Not reproduced |
| Table 1 | AdaBoost F1 | 0.847 | 0.8387 | 0.0083 | Within tolerance |
| Table 1 | AdaBoost AUC-ROC | 0.955 | 0.952 | 0.003 | Within tolerance |
| Table 1 | Logistic Regression accuracy | 0.8989 | 0.8989 | 0.0 | Exact |
| Table 1 | Logistic Regression F1 | 0.842 | 0.8417 | 0.0003 | Exact |
| Table 1 | Logistic Regression AUC-ROC | 0.951 | 0.951 | 0.0 | Exact |
| Table 1 | KNN accuracy | 0.8811 | 0.8833 | 0.0022 | Within tolerance |
| Table 1 | KNN F1 | 0.804 | 0.8094 | 0.0054 | Within tolerance |
| Table 1 | KNN AUC-ROC | 0.904 | 0.8984 | 0.0056 | Within tolerance |
| Table 1 | Naive Bayes accuracy | 0.8 | 0.8 | 0.0 | Exact |
| Table 1 | Naive Bayes F1 | 0.754 | 0.7541 | 0.0001 | Exact |
| Table 1 | Naive Bayes AUC-ROC | 0.907 | 0.9069 | 0.0001 | Exact |
| Sec 5.3 | CPO-A2C selected features | 65 | 53.0 | 12 | Not reproduced |
| Fig. 4a | Phase I best validation accuracy | 0.921 | 0.9238 | 0.0028 | Within tolerance |
| Sec 5.4 / Fig. 7 | Confusion count TN | 578 | 548.0 | 30 | Not reproduced |
| Sec 5.4 / Fig. 7 | Confusion count FP | 12 | 42.0 | 30 | Not reproduced |
| Sec 5.4 / Fig. 7 | Confusion count FN | 77 | 61.0 | 16 | Not reproduced |
| Sec 5.4 / Fig. 7 | Confusion count TP | 233 | 249.0 | 16 | Not reproduced |
| Table 2 | McNemar CPO-A2C vs Random Forest: p-value | 0.617 | 0.0184 | 0.5986 | Not reproduced |
| Table 2 | McNemar vs Random Forest: significance decision (p<0.05) | not significant | significant | None | Not reproduced |
| Table 2 | McNemar CPO-A2C vs SVM: p-value | 0.689 | 0.0171 | 0.6719 | Not reproduced |
| Table 2 | McNemar vs SVM: significance decision (p<0.05) | not significant | significant | None | Not reproduced |
| Table 2 | McNemar CPO-A2C vs Logistic Regression: p-value | 0.874 | 0.1124 | 0.7616 | Not reproduced |
| Table 2 | McNemar vs Logistic Regression: significance decision (p<0.05) | not significant | not significant | None | Exact |
| Table 2 | McNemar CPO-A2C vs AdaBoost: p-value | 1.0 | 0.302 | 0.698 | Not reproduced |
| Table 2 | McNemar vs AdaBoost: significance decision (p<0.05) | not significant | not significant | None | Exact |
| Table 2 | McNemar CPO-A2C vs KNN: p-value | 0.014 | 0.9141 | 0.9001 | Not reproduced |
| Table 2 | McNemar vs KNN: significance decision (p<0.05) | significant | not significant | None | Not reproduced |
| Table 2 | McNemar CPO-A2C vs Naive Bayes: p-value | 0.001 | 0.0 | 0.001 | Within tolerance |
| Table 2 | McNemar vs Naive Bayes: significance decision (p<0.05) | significant | significant | None | Exact |
| Table 3 | All features + A2C (no CPO) accuracy | 0.8989 | 0.8933 | 0.0056 | Within tolerance |
| Table 3 | All features + A2C (no CPO) F1 | 0.845 | 0.8373 | 0.0077 | Within tolerance |
| Table 3 | All features + A2C (no CPO) AUC-ROC | 0.952 | 0.9375 | 0.0145 | Not reproduced |
| Table 3 | CPO selection + short training accuracy | 0.9 | 0.8767 | 0.0233 | Not reproduced |
| Table 3 | CPO selection + short training F1 | 0.842 | 0.8141 | 0.0279 | Not reproduced |
| Table 3 | CPO selection + short training AUC-ROC | 0.941 | 0.9257 | 0.0153 | Not reproduced |
| Table 3 | Full CPO-A2C accuracy | 0.9011 | 0.8856 | 0.0155 | Not reproduced |
| Table 3 | Full CPO-A2C F1 | 0.84 | 0.8286 | 0.0114 | Within tolerance |
| Table 3 | Full CPO-A2C AUC-ROC | 0.937 | 0.9407 | 0.0037 | Within tolerance |
| Sec 5.10 | mean_p_TP | 0.874 | 0.9499 | 0.0759 | Within tolerance |
| Sec 5.10 | mean_p_TN | 0.115 | 0.0602 | 0.0548 | Within tolerance |
| Sec 5.10 | mean_p_FN | 0.227 | 0.1711 | 0.0559 | Within tolerance |
| Sec 5.10 | mean_p_FP | 0.611 | 0.7101 | 0.0991 | Within tolerance |
| Sec 5.10 | n_near_threshold | 48 | 43.0 | 5 | Within tolerance |
| Sec 5.10 | errors_near_threshold | 15 | 22.0 | 7 | Within tolerance |
| Sec 5.10 | total_errors | 89 | 103.0 | 14 | Not reproduced |
| Sec 5.3 | predict_proba time ratio SVM / CPO-A2C (x) | 447 | 2198.8077 | 1751.8077 | Not reproduced |
| Sec 5.7 | 5-fold CV cpo_a2c_mean | 0.8963 | 0.907 | 0.0107 | Not reproduced |
| Sec 5.7 | 5-fold CV logreg_mean | 0.9067 | 0.9067 | 0.0 | Exact |
| Sec 5.7 | 5-fold CV mean selected features | 56 | 55.0 | 1.0 | Within tolerance |
| Table 5 | saved RF accuracy | 0.9111 | 0.9989 | 0.0878 | Not reproduced |
| Table 5 | saved depth-3 tree accuracy | 1.0 | 1.0 | 0.0 | Exact |
| Table 5 | borrowed RF accuracy | 0.9833 | 0.99 | 0.0067 | Within tolerance |
| Table 5 | borrowed depth-3 tree accuracy | 0.9956 | 0.9943 | 0.0013 | Within tolerance |
| Table 5 | anydigpayment RF accuracy | 0.9889 | 0.9744 | 0.0145 | Not reproduced |
| Table 5 | anydigpayment depth-3 tree accuracy | 0.9278 | 0.9293 | 0.0015 | Within tolerance |
| Table 5 | merchantpay_dig RF accuracy | 0.9478 | 0.9833 | 0.0355 | Not reproduced |
| Table 5 | merchantpay_dig depth-3 tree accuracy | 0.9844 | 0.9883 | 0.0039 | Within tolerance |
| Table 5 | internet_use RF accuracy | 0.9456 | 1.0 | 0.0544 | Not reproduced |
| Table 5 | internet_use depth-3 tree accuracy | 1.0 | 1.0 | 0.0 | Exact |
| Table 4 | xgboost_269 | 0.9056 | 0.9011 | 0.0045 | Within tolerance |
| Table 4 | rf_tuned_108 | 0.9067 | 0.9067 | 0.0 | Exact |
| Table 4 | stacking_test_acc | 0.9056 | 0.9 | 0.0056 | Within tolerance |
| Table 4 | stacking_cv_mean | 0.9113 | 0.9097 | 0.0016 | Within tolerance |

## Arm `clean` (preprocessing fitted on training rows only)

Status counts: Exact: 15, Within tolerance: 21, Not reproduced: 23

| Ref | Metric | Reported | Recomputed | |Diff| | Status |
|---|---|---|---|---|---|
| Table 1 | Random Forest accuracy | 0.9056 | 0.9056 | 0.0 | Exact |
| Table 1 | Random Forest F1 | 0.851 | 0.8506 | 0.0004 | Exact |
| Table 1 | Random Forest AUC-ROC | 0.955 | 0.955 | 0.0 | Exact |
| Table 1 | SVM accuracy | 0.9044 | 0.9044 | 0.0 | Exact |
| Table 1 | SVM F1 | 0.847 | 0.8522 | 0.0052 | Within tolerance |
| Table 1 | SVM AUC-ROC | 0.95 | 0.95 | 0.0 | Exact |
| Table 1 | CPO-A2C accuracy | 0.9011 | 0.8856 | 0.0155 | Not reproduced |
| Table 1 | CPO-A2C F1 | 0.84 | 0.8286 | 0.0114 | Within tolerance |
| Table 1 | CPO-A2C AUC-ROC | 0.937 | 0.9407 | 0.0037 | Within tolerance |
| Table 1 | AdaBoost accuracy | 0.9 | 0.8944 | 0.0056 | Not reproduced |
| Table 1 | AdaBoost F1 | 0.847 | 0.8387 | 0.0083 | Within tolerance |
| Table 1 | AdaBoost AUC-ROC | 0.955 | 0.952 | 0.003 | Within tolerance |
| Table 1 | Logistic Regression accuracy | 0.8989 | 0.8989 | 0.0 | Exact |
| Table 1 | Logistic Regression F1 | 0.842 | 0.8417 | 0.0003 | Exact |
| Table 1 | Logistic Regression AUC-ROC | 0.951 | 0.951 | 0.0 | Exact |
| Table 1 | KNN accuracy | 0.8811 | 0.8833 | 0.0022 | Within tolerance |
| Table 1 | KNN F1 | 0.804 | 0.8094 | 0.0054 | Within tolerance |
| Table 1 | KNN AUC-ROC | 0.904 | 0.8984 | 0.0056 | Within tolerance |
| Table 1 | Naive Bayes accuracy | 0.8 | 0.8 | 0.0 | Exact |
| Table 1 | Naive Bayes F1 | 0.754 | 0.7541 | 0.0001 | Exact |
| Table 1 | Naive Bayes AUC-ROC | 0.907 | 0.9069 | 0.0001 | Exact |
| Sec 5.3 | CPO-A2C selected features | 65 | 53.0 | 12 | Not reproduced |
| Fig. 4a | Phase I best validation accuracy | 0.921 | 0.9238 | 0.0028 | Within tolerance |
| Sec 5.4 / Fig. 7 | Confusion count TN | 578 | 548.0 | 30 | Not reproduced |
| Sec 5.4 / Fig. 7 | Confusion count FP | 12 | 42.0 | 30 | Not reproduced |
| Sec 5.4 / Fig. 7 | Confusion count FN | 77 | 61.0 | 16 | Not reproduced |
| Sec 5.4 / Fig. 7 | Confusion count TP | 233 | 249.0 | 16 | Not reproduced |
| Table 2 | McNemar CPO-A2C vs Random Forest: p-value | 0.617 | 0.0184 | 0.5986 | Not reproduced |
| Table 2 | McNemar vs Random Forest: significance decision (p<0.05) | not significant | significant | None | Not reproduced |
| Table 2 | McNemar CPO-A2C vs SVM: p-value | 0.689 | 0.0171 | 0.6719 | Not reproduced |
| Table 2 | McNemar vs SVM: significance decision (p<0.05) | not significant | significant | None | Not reproduced |
| Table 2 | McNemar CPO-A2C vs Logistic Regression: p-value | 0.874 | 0.1124 | 0.7616 | Not reproduced |
| Table 2 | McNemar vs Logistic Regression: significance decision (p<0.05) | not significant | not significant | None | Exact |
| Table 2 | McNemar CPO-A2C vs AdaBoost: p-value | 1.0 | 0.302 | 0.698 | Not reproduced |
| Table 2 | McNemar vs AdaBoost: significance decision (p<0.05) | not significant | not significant | None | Exact |
| Table 2 | McNemar CPO-A2C vs KNN: p-value | 0.014 | 0.9141 | 0.9001 | Not reproduced |
| Table 2 | McNemar vs KNN: significance decision (p<0.05) | significant | not significant | None | Not reproduced |
| Table 2 | McNemar CPO-A2C vs Naive Bayes: p-value | 0.001 | 0.0 | 0.001 | Within tolerance |
| Table 2 | McNemar vs Naive Bayes: significance decision (p<0.05) | significant | significant | None | Exact |
| Table 3 | All features + A2C (no CPO) accuracy | 0.8989 | 0.8933 | 0.0056 | Within tolerance |
| Table 3 | All features + A2C (no CPO) F1 | 0.845 | 0.8373 | 0.0077 | Within tolerance |
| Table 3 | All features + A2C (no CPO) AUC-ROC | 0.952 | 0.9375 | 0.0145 | Not reproduced |
| Table 3 | CPO selection + short training accuracy | 0.9 | 0.8767 | 0.0233 | Not reproduced |
| Table 3 | CPO selection + short training F1 | 0.842 | 0.8141 | 0.0279 | Not reproduced |
| Table 3 | CPO selection + short training AUC-ROC | 0.941 | 0.9257 | 0.0153 | Not reproduced |
| Table 3 | Full CPO-A2C accuracy | 0.9011 | 0.8856 | 0.0155 | Not reproduced |
| Table 3 | Full CPO-A2C F1 | 0.84 | 0.8286 | 0.0114 | Within tolerance |
| Table 3 | Full CPO-A2C AUC-ROC | 0.937 | 0.9407 | 0.0037 | Within tolerance |
| Sec 5.10 | mean_p_TP | 0.874 | 0.9499 | 0.0759 | Within tolerance |
| Sec 5.10 | mean_p_TN | 0.115 | 0.0602 | 0.0548 | Within tolerance |
| Sec 5.10 | mean_p_FN | 0.227 | 0.1711 | 0.0559 | Within tolerance |
| Sec 5.10 | mean_p_FP | 0.611 | 0.7101 | 0.0991 | Within tolerance |
| Sec 5.10 | n_near_threshold | 48 | 43.0 | 5 | Within tolerance |
| Sec 5.10 | errors_near_threshold | 15 | 22.0 | 7 | Within tolerance |
| Sec 5.10 | total_errors | 89 | 103.0 | 14 | Not reproduced |
| Sec 5.3 | predict_proba time ratio SVM / CPO-A2C (x) | 447 | 2290.2024 | 1843.2024 | Not reproduced |
| Sec 5.7 | 5-fold CV cpo_a2c_mean | 0.8963 | 0.907 | 0.0107 | Not reproduced |
| Sec 5.7 | 5-fold CV logreg_mean | 0.9067 | 0.9067 | 0.0 | Exact |
| Sec 5.7 | 5-fold CV mean selected features | 56 | 55.0 | 1.0 | Within tolerance |

## Seed variability (clean arm)

CPO-A2C test accuracy over seeds [42, 43, 44, 45, 46]: [0.8856, 0.8956, 0.8922, 0.9033, 0.8967] (mean 0.8947, SD 0.0058).
