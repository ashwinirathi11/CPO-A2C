#!/usr/bin/env bash
# Full pipeline. Expected runtime: roughly 15-30 min on a 4-core CPU (CPO search dominates). No GPU needed.
set -euo pipefail
cd "$(dirname "$0")/.."
python -m pytest -q tests
python experiments/run_experiments.py --arm manuscript --screen
python experiments/run_experiments.py --arm clean --multi-seed
python experiments/run_extensions.py
python experiments/make_report.py
echo "Done. See results/reproduction_report.md"
